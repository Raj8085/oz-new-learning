import { useState } from "react"
import {
  Lightbulb,
  Users,
  Award,
  Calendar,
  BookOpen,
  Layers,
  Monitor,
  ChevronDown,
  Brain,
  Bot,
  Network,
  LineChart,
  Cpu,
} from "lucide-react"
import { Link } from "react-router-dom"

export default function AIMLCoursePage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [activeFaq, setActiveFaq] = useState(null)

  const toggleFaq = (index) => {
    setActiveFaq(activeFaq === index ? null : index)
  }

  return (
    <div className="bg-gradient-to-b from-gray-50 to-white min-h-screen">
      {/* Hero Section */}
      <div className="bg-blue-900 text-white">
        <div className="container mx-auto px-16 py-16 md:py-24">
          <div className="flex flex-col md:flex-row items-center md:mt-44">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Machine Learning & AI</h1>
              <p className="text-xl mb-6">
                Master the art of building intelligent systems with cutting-edge AI and ML technologies that are
                reshaping industries worldwide
              </p>
              <div className="flex flex-wrap gap-3 mb-8">
                <span className="bg-blue-700 px-3 py-1 rounded-full text-sm font-medium">Deep Learning</span>
                <span className="bg-blue-700 px-3 py-1 rounded-full text-sm font-medium">Neural Networks</span>
                <span className="bg-blue-700 px-3 py-1 rounded-full text-sm font-medium">Computer Vision</span>
                <span className="bg-blue-700 px-3 py-1 rounded-full text-sm font-medium">NLP</span>
                <span className="bg-blue-700 px-3 py-1 rounded-full text-sm font-medium">Reinforcement Learning</span>
              </div>
              <div className="flex gap-4">
                <Link to="/contact">
                <button className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold px-6 py-3 rounded-lg transition-all">
                  Enroll Now
                </button>
                </Link>
                <Link to="/contact">
                <button className="border-2 border-white hover:bg-white hover:text-blue-900 px-6 py-3 rounded-lg font-bold transition-all">
                  Download Syllabus
                </button>
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="relative">
                <div className="w-64 h-64 md:w-80 md:h-80 bg-blue-800 rounded-full flex items-center justify-center">
                  <Brain size={120} strokeWidth={1} />
                </div>
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-yellow-500 rounded-full flex items-center justify-center">
                  <Network size={36} strokeWidth={1} />
                </div>
                <div className="absolute -bottom-4 -left-4 w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center">
                  <Bot size={36} strokeWidth={1} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Key Info Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center mb-4">
              <Calendar className="text-blue-600 mr-3" size={24} />
              <h3 className="text-lg font-bold">Duration</h3>
            </div>
            <p className="text-gray-700">20 weeks (5 months)</p>
            <p className="text-gray-700">8 hours per week</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center mb-4">
              <BookOpen className="text-blue-600 mr-3" size={24} />
              <h3 className="text-lg font-bold">Prerequisites</h3>
            </div>
            <p className="text-gray-700">Basic Python programming</p>
            <p className="text-gray-700">Fundamentals of statistics and linear algebra</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center mb-4">
              <Award className="text-blue-600 mr-3" size={24} />
              <h3 className="text-lg font-bold">Certification</h3>
            </div>
            <p className="text-gray-700">Industry-recognized AI/ML certificate</p>
            <p className="text-gray-700">AI project portfolio</p>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="container mx-auto px-4 py-8">
        <div className="flex overflow-x-auto space-x-4 pb-2">
          <button
            onClick={() => setActiveTab("overview")}
            className={`px-4 py-2 font-medium rounded-lg whitespace-nowrap ${
              activeTab === "overview" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700"
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab("curriculum")}
            className={`px-4 py-2 font-medium rounded-lg whitespace-nowrap ${
              activeTab === "curriculum" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700"
            }`}
          >
            Curriculum
          </button>
          <button
            onClick={() => setActiveTab("projects")}
            className={`px-4 py-2 font-medium rounded-lg whitespace-nowrap ${
              activeTab === "projects" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700"
            }`}
          >
            Projects
          </button>
          <button
            onClick={() => setActiveTab("instructors")}
            className={`px-4 py-2 font-medium rounded-lg whitespace-nowrap ${
              activeTab === "instructors" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700"
            }`}
          >
            Instructors
          </button>
          <button
            onClick={() => setActiveTab("careers")}
            className={`px-4 py-2 font-medium rounded-lg whitespace-nowrap ${
              activeTab === "careers" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700"
            }`}
          >
            Career Paths
          </button>
        </div>

        {/* Tab Content */}
        <div className="bg-white p-6 rounded-xl shadow-md mt-4">
          {activeTab === "overview" && (
            <div>
              <h2 className="text-2xl font-bold mb-4">Course Overview</h2>
              <p className="text-gray-700 mb-6">
                Our Machine Learning & AI course is designed to transform practitioners into AI specialists capable of
                building intelligent systems. You'll learn to develop neural networks, implement computer vision
                solutions, create natural language processing applications, and deploy production-ready AI models that
                solve real-world problems.
              </p>

              <h3 className="text-xl font-bold mb-3">What You'll Learn</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-lg mr-3">
                    <Brain size={20} className="text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold">Deep Learning Fundamentals</h4>
                    <p className="text-gray-700">Neural networks, backpropagation, and optimization algorithms</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-lg mr-3">
                    <Monitor size={20} className="text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold">Computer Vision</h4>
                    <p className="text-gray-700">Image classification, object detection, and segmentation with CNNs</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-lg mr-3">
                    <Bot size={20} className="text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold">Natural Language Processing</h4>
                    <p className="text-gray-700">Text analysis, sentiment analysis, and transformer models</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-lg mr-3">
                    <Cpu size={20} className="text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold">MLOps & Deployment</h4>
                    <p className="text-gray-700">Model serving, monitoring, and scaling AI systems</p>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-bold mb-3">Course Highlights</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Lightbulb size={20} className="text-yellow-500 mr-2" />
                    <h4 className="font-bold">Hands-on Projects</h4>
                  </div>
                  <p className="text-gray-700">80% practical implementation with real-world datasets</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Users size={20} className="text-yellow-500 mr-2" />
                    <h4 className="font-bold">AI Research Workshops</h4>
                  </div>
                  <p className="text-gray-700">Explore cutting-edge AI research papers and implementations</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Award size={20} className="text-yellow-500 mr-2" />
                    <h4 className="font-bold">AI Model Portfolio</h4>
                  </div>
                  <p className="text-gray-700">Build a portfolio of deployed AI models and applications</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === "curriculum" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Curriculum</h2>

              <div className="mb-6">
                <h3 className="text-xl font-bold mb-4">Module 1: Machine Learning Foundations</h3>
                <div className="space-y-3">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-bold">Week 1-2: ML Fundamentals</h4>
                    <ul className="list-disc list-inside text-gray-700 ml-4">
                      <li>Supervised vs. unsupervised learning</li>
                      <li>Linear and logistic regression</li>
                      <li>Decision trees and random forests</li>
                      <li>Model evaluation and validation techniques</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-bold">Week 3-4: Feature Engineering & Selection</h4>
                    <ul className="list-disc list-inside text-gray-700 ml-4">
                      <li>Data preprocessing and normalization</li>
                      <li>Feature extraction and transformation</li>
                      <li>Dimensionality reduction (PCA, t-SNE)</li>
                      <li>Feature importance and selection methods</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-bold mb-4">Module 2: Deep Learning & Neural Networks</h3>
                <div className="space-y-3">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-bold">Week 5-7: Neural Network Fundamentals</h4>
                    <ul className="list-disc list-inside text-gray-700 ml-4">
                      <li>Perceptrons and multilayer networks</li>
                      <li>Activation functions and backpropagation</li>
                      <li>Gradient descent and optimization algorithms</li>
                      <li>Building neural networks with PyTorch and TensorFlow</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-bold">Week 8-10: Advanced Neural Architectures</h4>
                    <ul className="list-disc list-inside text-gray-700 ml-4">
                      <li>Convolutional Neural Networks (CNNs)</li>
                      <li>Recurrent Neural Networks (RNNs) and LSTMs</li>
                      <li>Generative Adversarial Networks (GANs)</li>
                      <li>Transfer learning and fine-tuning</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-bold mb-4">Module 3: Computer Vision & NLP</h3>
                <div className="space-y-3">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-bold">Week 11-13: Computer Vision Applications</h4>
                    <ul className="list-disc list-inside text-gray-700 ml-4">
                      <li>Image classification and object detection</li>
                      <li>Semantic segmentation</li>
                      <li>Face recognition and analysis</li>
                      <li>Vision transformers and YOLO architectures</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-bold">Week 14-16: Natural Language Processing</h4>
                    <ul className="list-disc list-inside text-gray-700 ml-4">
                      <li>Text preprocessing and word embeddings</li>
                      <li>Sentiment analysis and text classification</li>
                      <li>Transformer models (BERT, GPT)</li>
                      <li>Building conversational AI and chatbots</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold mb-4">Module 4: Advanced AI & Deployment</h3>
                <div className="space-y-3">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-bold">Week 17-18: Reinforcement Learning</h4>
                    <ul className="list-disc list-inside text-gray-700 ml-4">
                      <li>Markov decision processes</li>
                      <li>Q-learning and policy gradients</li>
                      <li>Deep reinforcement learning</li>
                      <li>Multi-agent systems</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-bold">Week 19-20: MLOps & Production AI</h4>
                    <ul className="list-disc list-inside text-gray-700 ml-4">
                      <li>Model deployment and serving</li>
                      <li>Monitoring and maintaining AI systems</li>
                      <li>Scaling AI applications</li>
                      <li>Capstone project implementation</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "projects" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Projects You'll Build</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">Intelligent Image Classifier</h3>
                  <p className="text-gray-700 mb-4">
                    Build a deep learning model that can classify images across multiple categories with high accuracy,
                    using transfer learning and fine-tuning techniques.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">CNN</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Transfer Learning</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">PyTorch</span>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">Sentiment Analysis Engine</h3>
                  <p className="text-gray-700 mb-4">
                    Create an NLP system that analyzes sentiment in text data from social media, reviews, or customer
                    feedback with high accuracy using transformer models.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">BERT</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Transformers</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Hugging Face</span>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">Object Detection System</h3>
                  <p className="text-gray-700 mb-4">
                    Develop a real-time object detection system that can identify and track multiple objects in video
                    streams using state-of-the-art architectures.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">YOLO</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Computer Vision</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">OpenCV</span>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">Generative AI Art Creator</h3>
                  <p className="text-gray-700 mb-4">
                    Build a generative model that can create original artwork, music, or text based on learned patterns
                    from existing creative works.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">GANs</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Diffusion Models</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Stable Diffusion</span>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">Intelligent Chatbot</h3>
                  <p className="text-gray-700 mb-4">
                    Create a conversational AI system that can understand natural language queries and provide helpful,
                    contextually relevant responses.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">LLMs</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">RAG</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">LangChain</span>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">Capstone AI Project</h3>
                  <p className="text-gray-700 mb-4">
                    Design and develop a complex AI application of your choice that solves a real-world problem and
                    incorporates multiple AI techniques learned throughout the course.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">MLOps</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Full Stack AI</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Cloud Deployment</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "instructors" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Meet Your Instructors</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-gray-50 p-6 rounded-lg flex flex-col items-center text-center">
                  <div className="w-32 h-32 bg-gray-200 rounded-full mb-4 overflow-hidden">
                    <img src="/api/placeholder/150/150" alt="Instructor" className="w-full h-full object-cover" />
                  </div>
                  <h3 className="text-xl font-bold">Dr. Emily Zhang</h3>
                  <p className="text-blue-600 mb-2">AI Research Scientist</p>
                  <p className="text-gray-700 mb-4">
                    Ph.D. in Machine Learning with 8+ years of experience. Previously led AI research teams at Google
                    Brain and DeepMind.
                  </p>
                  <div className="flex gap-3">
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Deep Learning</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Computer Vision</span>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg flex flex-col items-center text-center">
                  <div className="w-32 h-32 bg-gray-200 rounded-full mb-4 overflow-hidden">
                    <img src="/api/placeholder/150/150" alt="Instructor" className="w-full h-full object-cover" />
                  </div>
                  <h3 className="text-xl font-bold">Alex Ramirez</h3>
                  <p className="text-blue-600 mb-2">NLP Specialist</p>
                  <p className="text-gray-700 mb-4">
                    10 years of experience in natural language processing and large language models. Former lead at
                    OpenAI.
                  </p>
                  <div className="flex gap-3">
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">NLP</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Transformers</span>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg flex flex-col items-center text-center">
                  <div className="w-32 h-32 bg-gray-200 rounded-full mb-4 overflow-hidden">
                    <img src="/api/placeholder/150/150" alt="Instructor" className="w-full h-full object-cover" />
                  </div>
                  <h3 className="text-xl font-bold">Dr. Marcus Johnson</h3>
                  <p className="text-blue-600 mb-2">MLOps Engineer</p>
                  <p className="text-gray-700 mb-4">
                    Expert in deploying and scaling AI systems in production with 9 years of experience at AWS and
                    Netflix.
                  </p>
                  <div className="flex gap-3">
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">MLOps</span>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">Cloud AI</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "careers" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Career Opportunities</h2>

              <div className="mb-8">
                <h3 className="text-xl font-bold mb-4">Job Roles After Completion</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h4 className="font-bold text-lg mb-2">Machine Learning Engineer</h4>
                    <p className="text-gray-700 mb-2">Average Salary: $120,000 - $180,000</p>
                    <p className="text-gray-700">
                      Design and implement machine learning models and systems for production environments.
                    </p>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h4 className="font-bold text-lg mb-2">AI Research Scientist</h4>
                    <p className="text-gray-700 mb-2">Average Salary: $130,000 - $200,000</p>
                    <p className="text-gray-700">
                      Conduct cutting-edge research to advance the field of artificial intelligence.
                    </p>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h4 className="font-bold text-lg mb-2">Computer Vision Engineer</h4>
                    <p className="text-gray-700 mb-2">Average Salary: $125,000 - $190,000</p>
                    <p className="text-gray-700">
                      Develop systems that can analyze and interpret visual information from the world.
                    </p>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-bold mb-4">Industry Demand</h3>
              <div className="bg-blue-50 p-6 rounded-lg mb-8">
                <div className="flex items-start mb-4">
                  <div className="bg-blue-100 p-2 rounded-lg mr-3">
                    <Lightbulb size={20} className="text-blue-600" />
                  </div>
                  <div>
                    <p className="text-gray-700">
                      AI and ML specialists are among the most sought-after professionals globally. According to recent
                      industry reports, there's a <span className="font-bold">71% growth</span> in AI job postings over
                      the past two years, with demand far exceeding the supply of qualified professionals.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-lg mr-3">
                    <Lightbulb size={20} className="text-blue-600" />
                  </div>
                  <div>
                    <p className="text-gray-700">
                      Every industry from healthcare and finance to retail and manufacturing is investing heavily in AI
                      capabilities, creating diverse opportunities for AI specialists across sectors and geographies.
                    </p>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-bold mb-4">Career Support</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-green-100 p-2 rounded-lg mr-3">
                    <Users size={20} className="text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-bold">AI Portfolio Development</h4>
                    <p className="text-gray-700">
                      Build a professional portfolio of AI projects that demonstrate your capabilities to employers.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-green-100 p-2 rounded-lg mr-3">
                    <Users size={20} className="text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-bold">Technical Interview Preparation</h4>
                    <p className="text-gray-700">Practice AI-specific technical interviews with industry veterans.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-green-100 p-2 rounded-lg mr-3">
                    <Users size={20} className="text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-bold">AI Industry Networking</h4>
                    <p className="text-gray-700">
                      Connect with our network of AI companies and hiring partners actively seeking talent.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* FAQ Section */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>

        <div className="max-w-3xl mx-auto">
          {[
            {
              question: "Do I need a background in AI or machine learning?",
              answer:
                "No prior AI experience is required, but basic Python programming skills and understanding of fundamental mathematics (statistics and linear algebra) will help you succeed in the course.",
            },
            {
              question: "What hardware requirements are needed for this course?",
              answer:
                "You'll need a computer with at least 16GB RAM and a dedicated GPU (NVIDIA preferred) for deep learning tasks. Alternatively, we provide cloud-based GPU resources for students without suitable hardware.",
            },
            {
              question: "How is the course structured between theory and practice?",
              answer:
                "The course follows an 80/20 approach with 80% hands-on practical implementation and 20% theoretical foundations. You'll be building real AI models from the first week.",
            },
            {
              question: "Will I be able to build my own AI applications after this course?",
              answer:
                "By the end of the course, you'll have the skills to conceptualize, design, implement, and deploy AI applications across various domains including computer vision, NLP, and generative AI.",
            },
            {
              question: "How does this course stay current with rapidly evolving AI technologies?",
              answer:
                "Our curriculum is continuously updated to reflect the latest advancements in AI. We incorporate new research papers, techniques, and tools as they emerge in the field.",
            },
            {
              question: "What kind of support is provided during and after the course?",
              answer:
                "During the course, you'll have access to instructor office hours, peer discussion forums, and teaching assistants. After completion, you'll join our alumni network with continued access to career services and community resources.",
            },
          ].map((faq, index) => (
            <div key={index} className="mb-4">
              <button
                className="flex justify-between items-center w-full p-4 bg-white rounded-lg shadow-sm hover:bg-gray-50 focus:outline-none"
                onClick={() => toggleFaq(index)}
              >
                <span className="font-bold text-left">{faq.question}</span>
                <ChevronDown size={20} className={`transition-transform ${activeFaq === index ? "rotate-180" : ""}`} />
              </button>

              {activeFaq === index && (
                <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                  <p className="text-gray-700">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-blue-900 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Master AI & Machine Learning?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Join our next cohort and transform your career with cutting-edge AI skills that are reshaping industries
            worldwide.
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/contact">
            <button className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold px-8 py-4 rounded-lg text-lg transition-all">
              Enroll Now
            </button>
            </Link>
            <Link to="/contact">
            <button className="border-2 border-white hover:bg-white hover:text-blue-900 px-8 py-4 rounded-lg font-bold text-lg transition-all">
              Download Course Brochure
            </button>
            </Link>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="bg-white p-8 rounded-xl shadow-md max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold mb-6 text-center">Have Questions? Contact Us</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-start mb-6">
                <div className="bg-blue-100 p-2 rounded-lg mr-3">
                  <Calendar size={20} className="text-blue-600" />
                </div>
                <div>
                  <h4 className="font-bold">Next Batch Starts</h4>
                  <p className="text-gray-700">September 15, 2025</p>
                </div>
              </div>

              <div className="flex items-start mb-6">
                <div className="bg-blue-100 p-2 rounded-lg mr-3">
                  <Users size={20} className="text-blue-600" />
                </div>
                <div>
                  <h4 className="font-bold">Limited Seats</h4>
                  <p className="text-gray-700">Only 25 students per batch</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-blue-100 p-2 rounded-lg mr-3">
                  <Award size={20} className="text-blue-600" />
                </div>
                <div>
                  <h4 className="font-bold">Early Bird Discount</h4>
                  <p className="text-gray-700">25% off until August 15, 2025</p>
                </div>
              </div>
            </div>

            <div>
              <form>
                <div className="mb-4">
                  <label className="block text-gray-700 mb-2" htmlFor="name">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Your Name"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 mb-2" htmlFor="email">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Your Email"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 mb-2" htmlFor="query">
                    Your Query
                  </label>
                  <textarea
                    id="query"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="How can we help you?"
                    rows="3"
                  ></textarea>
                </div>

                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition-all">
                  Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Tech Stack Section */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">AI Technologies You'll Master</h2>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center">
              <div className="h-16 w-16 flex items-center justify-center mb-4">
                <Brain size={40} className="text-blue-600" />
              </div>
              <h3 className="font-bold text-center">TensorFlow</h3>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center">
              <div className="h-16 w-16 flex items-center justify-center mb-4">
                <Layers size={40} className="text-blue-600" />
              </div>
              <h3 className="font-bold text-center">PyTorch</h3>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center">
              <div className="h-16 w-16 flex items-center justify-center mb-4">
                <Bot size={40} className="text-blue-600" />
              </div>
              <h3 className="font-bold text-center">Transformers</h3>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center">
              <div className="h-16 w-16 flex items-center justify-center mb-4">
                <Monitor size={40} className="text-blue-600" />
              </div>
              <h3 className="font-bold text-center">Computer Vision</h3>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center">
              <div className="h-16 w-16 flex items-center justify-center mb-4">
                <LineChart size={40} className="text-blue-600" />
              </div>
              <h3 className="font-bold text-center">Scikit-learn</h3>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center">
              <div className="h-16 w-16 flex items-center justify-center mb-4">
                <Cpu size={40} className="text-blue-600" />
              </div>
              <h3 className="font-bold text-center">MLOps Tools</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
