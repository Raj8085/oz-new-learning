import AboutPage from '@/component/about-component/AboutInfo'
import Footer from '@/components/layout/Footer'
import Navbar from '@/components/layout/Navbar'
import React from 'react'

const About = () => {
  return (
    <div>
        {/* <Navbar /> */}
        <AboutPage/>
        <Footer />
    </div>
  )
}

export default About